
<div class="container">
<div class="wrap_slidebanner">
<div class="type-3">
    <div class="container"> 
        <div class="row">
            <div class="swiper-container">
                <div class="swiper-wrapper">                                                            
                    <div class="swiper-slide">
                                 <div class="size-imslide" style="background-image: url('<?php bloginfo("template_directory"); ?>/images/1.jpg'); ">
                                 <div class="flex-caption">
                                <a class="slide-button" href="#">Pick your shoes</a>
                                <h2 class="home-slide-title"><b>Shoes 2013 Collection</b></h2> 
                                <p class="slider-caption1">New arrivals are here. Browse our shoe collection and start this year in style.</p>           
                                </div>   
                                </div>               
                    </div>
                    <div class="swiper-slide">
                          <div class="size-imslide" style="background-image: url('<?php bloginfo("template_directory"); ?>/images/2.jpg'); ">
                          <div class="flex-caption">
                                <a class="slide-button" href="#">See Details</a>
                                <h2 class="home-slide-title"><b>The New iPad</b></h2> 
                                <p class="slider-caption">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>           
                                </div>   
                        </div>         
                    </div>
                    <div class="swiper-slide">
                          <div class="size-imslide" style="background-image: url('<?php bloginfo("template_directory"); ?>/images/3.jpg'); ">

                        </div>             
                    </div>
                    <div class="swiper-slide">
                       <div class="size-imslide" style="background-image: url('<?php bloginfo("template_directory"); ?>/images/4.jpg'); ">
                       <div class="flex-caption">
                                <a class="slide-button" href="#">Browse Shoes</a>
                                <h2 class="home-slide-title"><b>Browse Shoes</b></h2> 
                                <p class="slider-caption">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>           
                                </div> 
                        </div>                 
                    </div>
                </div>                   
            </div>       
        </div>
        <div class="contact">
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div> 
    <!-- Add Arrows --> 
</div>        
</div>

</div>
