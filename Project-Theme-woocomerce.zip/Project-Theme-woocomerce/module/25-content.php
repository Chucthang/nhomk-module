<div id="color_picker">
                        <input type="color" id="color-picker-primary" value="#b92193">
                        <input type="color" id="color-picker-menu" value="#b9212e">
                        <input type="color"  id="color-picker-bg"  value="#54ec43" >
</div>