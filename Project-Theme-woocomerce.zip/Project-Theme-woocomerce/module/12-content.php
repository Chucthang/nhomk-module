<div class="type-12">
    <div class="mini-cart">
        <span class="hidecart-icon">Hide Cart</span>
        <div class="dropdown_widget dropdown_widget_cart" >
          <div class="widget_shopping_cart_content">

                <ul class="cart_list product_list_widget ">
                    <li>
                        <a href="#">
                            <img width="138" height="138" src="<?php bloginfo('template_directory'); ?> /images/cart-user.jpeg" alt="6855302802_1_1_1" sizes="(max-width: 138px) 100vw, 138px">Ripped Skinny Jeans                       
                        </a>
                        <span class="quantity">1 × <span class="amount">$169.00</span></span>      
                    </li>
                    <li>
                        <a href="#">
                            <img width="138" height="138" src="<?php bloginfo('template_directory'); ?> /images/cart-user.jpeg" alt="6855302802_1_1_1" sizes="(max-width: 138px) 100vw, 138px">Ripped Skinny Jeans                       
                        </a>
                        <span class="quantity">1 × <span class="amount">$169.00</span></span>      
                    </li>



                </ul><!-- end product list -->


                    <p class="total"><strong>Subtotal:</strong> <span class="amount">$407.00</span></p>


                    <p class="buttons">
                        <a href="#" class=" wc-forward">View Cart</a>
                        <a href="#" class="wc-forward">Checkout</a>
                    </p>
                </div>
            </div>
        </div>
</div>