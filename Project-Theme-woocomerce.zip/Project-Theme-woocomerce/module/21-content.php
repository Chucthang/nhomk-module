<div class="type-21">
    <div class="container setcontainer">
        <div class="wrap-portfolio">
            <div class="wrap_br_title">
                <div class="breadcum">
                    <span class="icon-home"><i class="fa fa-home"></i> / </span>
                    <span class="txt-home"><a>Contact us</a></span>
                </div>
                <h1 class="head-title-21">Portfolio 2 column</h1>
            </div>

            <div class="row">

                <?php

                $args = array(
                    'post_status' => 'publish', // Chỉ lấy những bài viết được publish
                    // 'showposts' => array(), // số lượng bài viết
                    'cat' => 39,
                    'posts_per_page' => '6',
                    'paged' => 1,
                );
                $getposts = new WP_query($args);
                global $wp_query;
                $wp_query->in_the_loop = true;
                while ($getposts->have_posts()) : $getposts->the_post();
                    if (have_posts() && !is_single() &&  has_post_thumbnail()  && !post_password_required() || has_post_format('image')) :
                        ?>
                        <div class="col-md-6 col-md-6-21">
                            <div class="col-module-21">
                                <div class="box-module-21">
                                    <?php the_post_thumbnail('portfolio-2coloum'); ?>

                                    <div class="zoom-icon">
                                        <a class="zoom-block" style="background: url('<?php bloginfo('template_directory'); ?>/images/block.png') no-repeat top left" alt=""></a>
                                        <a class="zoom-eye" style="background: url('<?php bloginfo('template_directory'); ?>/images/eye.png') no-repeat top left" alt=""></a>
                                    </div>
                                </div>
                                <h2 class="title-21"><?php the_title(); ?></h2>
                                <p class="content-21">
                                    <?php $content = get_the_content();
                                            $content = preg_replace("/<img[^>]+\>/i", " ", $content);
                                            $content = apply_filters('the_content', $content);
                                            $content = str_replace(']]>', ']]>', $content);
                                            echo $content;  ?>
                                </p>

                            </div>
                        </div>

                    <?php
                        else : ?>
                        <h1> KHÔNG TÌM THẤY BÀI VIẾT </h1>

                <?php
                    endif;
                endwhile;
                wp_reset_postdata();
                ?>

            </div>
        </div>
    </div>
</div>