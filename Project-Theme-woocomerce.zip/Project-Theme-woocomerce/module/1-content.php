
<div class="type-1000">
        <div id="wrap_header" class="elem">
                <div class="container padding-header">
                    <div class="wrap_logo_text">
                        <h1 class="logo">Titnia </h1>
                        <h2  class="textt">Just another UFO themes demo site</h2>
                    </div>
                    <div class="wrap_text_search">
                       
                          <div id="searchbar">
                                           
                                    <form>
                                        <div>
                                            <input type="text" name="s"  class="search-ajax sform " value="" x-webkit-speech="">
                                          
                                        </div>
                                    </form>
                           </div>
                         <ul id="myacc_cart_checkout">
                            <li><a href="#" >My account</a></li>
                            <li><a href="#" >Cart</a></li>
                            <li><a href="#" >Checkout</a></li>
                        </ul>

                    </div>
                                  <div class="social-icon">
                                            <span class="call"> Call us:</span>
                                            <span class="phone">1-800-234-4534</span>  
                                            <span class="follow">Follow:</span>	
                                          
                                         <a href="#" class="ic"><i class="fa fa-facebook hv"></i> </a>		
                                            <a href="#" class="ic"><i class="fa fa-twitter hv"></i></a>
                                            <a href="#" class="ic"><i class="fa fa-google-plus hv"></i></a>	
                                            <a href="#" class="ic"><i class="fa fa-pinterest hv"></i></a>	
                                       
					
                                
                                    </div>

                                    <?php   get_template_part('module/2', 'content'); ?>
              
        </div>
    </div>
    <?php   get_template_part('module/25', 'content'); ?>
 </div>


                            