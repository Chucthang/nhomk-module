<nav class="navbar navbar-expand-sm navbar-light bg-nav">
                                
                                <a class="respon" href="#"><i class="fa fa-bars"></i> </a>
                        
                            <?php
                                                wp_nav_menu(array(
                                                    'theme_location'  => 'primary-menu', // Gọi menu đã đăng ký trong function
                                                    'depth'           => 3,     // Cấu hình dropdown 2 cấp
                                                    'container'       => false, // Thẻ div bọc menu
                                                    'menu_class'      => 'navbar-nav ', // Class của nav bootstrap
                                                    'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                                                    'walker'          => new WP_Bootstrap_Navwalker()
                                                ));
                                            ?>
                            
                            <div class="price_menu">
                            <span class="ch_color">CART : $772.00</span>
                        </div>
  </nav>

  <?php    get_template_part('module/12', 'content'); ?>