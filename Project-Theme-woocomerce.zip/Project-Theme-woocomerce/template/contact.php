<?php
/*
 Template Name: Contact
 */
//  get_header(); 
?>
 <?php get_template_part('module/15', 'content');  ?>

<?php 
//  get_footer();  // Footer
