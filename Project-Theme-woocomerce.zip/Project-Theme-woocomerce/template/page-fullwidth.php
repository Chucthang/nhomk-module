<?php 
/*
 Template Name: Page full width
 */
     get_template_part('module/17', 'content');
