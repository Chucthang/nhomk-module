
<?php

 get_header(); // Header?>

<div id="loader"><img class="loadim" src="<?php bloginfo('template_directory'); ?>/images/loader.gif" alt=""></div>
 <div class="box_ajax"> 
 
     <div class="none-below">
<?php 
     get_template_part('module/3', 'content');  ?>


<?php          
 if (is_active_sidebar('minhcanh-4')) {   // Module 4 ( Widget )
     dynamic_sidebar('minhcanh-4');
 }  

 ?>

 <?php 
  wrap_above(); // container ..v.v..


       get_template_part('module/6', 'content');


 wrap_below();  // container ..v.v..
 ?>

</div>
</div>
<?php 
 get_footer();  // Footer