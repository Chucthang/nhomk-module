<?php
/*
 Template Name: PortFolio 2 Column
 */

?>
<?php get_template_part('module/21', 'content');  ?>

<?php
