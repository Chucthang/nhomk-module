<?php get_template_part('module/7', 'content'); ?>


<?php wp_footer(); ?>
<script type="text/javascript">
    var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";

    var currentPath = window.location.pathname; //Lay duong dan cua trang hien tai
    var currentTitle = document.title; //Lay title hien tai
    var currentPage = 1;

    var page = 2;
    jQuery(function($) { // LoadMore widget product of category
        $('body').on('click', '.load_onee', function() {

            var pageone = $(this).data("perpage");
            var termid = $(this).data("termid");
            // debugger;



            var data = {
                'action': 'load_posts_one',
                'page': page,
                'perpage': pageone,
                'termid': termid,
                'security': '<?php echo wp_create_nonce("load_more_posts"); ?>'
            };
            // debugger;

            $.ajax({
                type: 'POST',
                'async': true,
                url: ajaxurl,
                data: data,
                beforeSend: function() {
                    $('#loader_widget').show();
                },
                success: function(response) {
                    // debugger;

                    if (response != '') {

                        $('.products').append(response);
                        page++;
                    } else {
                        // debugger;
                        $('.load_onee').hide();
                        // debugger;
                    }
                },
                complete: function() {
                    $('#loader_widget').hide();
                }
            });
        });
    });



    /*-------------------------------------- Phân trang archive --------------------------*/
    var page_archive = '';
    jQuery(function($) {
        $('body').on('click', '.a-pt', function() {

            var pageid = $(this).data("pagi");
            var cateid = $(this).data("cateid");
            $("#loader").show();
            //    alert('true');
            // debugger;
            if (pageid == 1) {
                page_archive = 1;
            } else {
                page_archive = pageid;
            }

            var testdata = {
                'action': 'pagination_archive',
                'category': cateid,
                'page': page_archive,
                'security': '<?php echo wp_create_nonce("load_more_posts"); ?>'
            };


            $.ajax({
                type: 'POST',
                // 'async':false,
                url: ajaxurl,
                data: testdata,
                beforeSend: function() {
                    // $('#loader_pagination').show();
                    $('#loader').hide();
                    // $('.products').hide();
                },
                success: function(response) {

                    if (response != '') {

                        $('.products').html(response);

                    }
                },
                complete: function() {
                    // $('#loader_pagination').hide();
                    $('#loader').hide();
                    // $('.products').show();
                }
            });

        });
    });




    /*------------------------------------------------------- LẤY ID CHO ARCHIVE.PHP chuyển trang---------------------------*/



    // $(document).ready(function(){





    $(document).on('click', ".getUrl ", function() {
        var geturl = $(this).data("url");

        // debugger;


        $.ajax({
            type: 'GET',
            // 'async':false,
            url: geturl,
            beforeSend: function() {
                $('#loader').show();
                $('.box_ajax').hide();
            },
            success: function(response) {

                history.replaceState(null, '', geturl);
                // debugger;
                if (response != '') {
                    // debugger;
                    $('.box_ajax').html(response);
                    // debugger;
                } else {
                    // debugger;
                    alert("khong co");
                    // debugger;
                }
            },
            complete: function() {
                $('#loader').hide();
                $('.box_ajax').show();
                // debugger;
            }
        });

    });

    // });

    /*---------------------------------------- SEARCH AUTOCOMPLETE ----------------------------------*/
    jQuery(function($) {
        var timeout = null;
        $(".search-ajax").on('keyup', function() {
            var dataa = $('.search-ajax').val();
            // clearTimeout(timeout); 
            // timeout = setTimeout(function (){
            call_ajax(dataa);
            // }, 400);


        });

        function call_ajax(dataa) {
            $.ajax({
                type: 'POST',
                // async: false,
                url: ajaxurl,
                data: {
                    'action': 'Post_filters',
                    'data': dataa
                },
                success: function(response) {
                    if (response != '') {
                        $('.box_ajax').html(response); // show dữ liệu khi trả về 


                    }

                }
            });
        }
    });



    /*--------------------------------- PHÂN TRANG TÌM KIẾM ---------------------------------*/

    load_pagination();

    function load_pagination() {
        var pagesearch = 2;
        $('body').on('click', '.loadmore_search', function() {
            var dtsearch = $('.search-ajax').val();
            console.log(dtsearch);
            var datap = {
                'action': 'pagination_post_filters',
                'page': pagesearch,
                'data': dtsearch,
                'security': '<?php echo wp_create_nonce("load_more_posts"); ?>'
            };


            console.log(datap);
            $.ajax({
                type: 'POST',
                // async: false,
                url: ajaxurl,
                data: datap,
                success: function(response) {
                    if (response != '') {
                        $('.products').append(response);

                        pagesearch++;

                        $(".search-ajax").on("input", function() {
                            $('.load_search').show();
                            pagesearch = 2;
                        });
                    } else {
                        $('.loadmore_search').hide();
                    }

                }
            });
        });
    }
</script>
</body>
<!--end body-->

</html>
<!--end html -->