soft.Data.Schema.ScriptDom.Sql.Privilege80)">
      <param name="node">The specified type of fragment</param>
    </member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.PrivilegeSecurityElement80)">
      <param name="node">The specified type of fragment</param>
    </member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.ProcedureParameter)">
      <param name="node">The specified type of fragment</param>
    </member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.ProcedureReference)">
      <param name="node">The specified type of fragment</param>
    </member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.ProcedureStatementBody)">
      <param name="node">The specified type of fragment</param>
    </member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.ProcedureStatementBodyBase)">
      <param name="node">The specified type of fragment</param>
    </member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.ProcessAffinityRange)"></member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.ProviderEncryptionSource)">
      <param name="node">The specified type of fragment</param>
    </member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.ProviderKeyNameKeyOption)">
      <param name="node">The specified type of fragment</param>
    </member>
    <member name="M:Microsoft.Data.Schema.ScriptDom.Sql.TSqlFragmentVisitor.Visit(Microsoft.Data.Schema.ScriptDom.Sql.QualifiedJoin)">
      <p